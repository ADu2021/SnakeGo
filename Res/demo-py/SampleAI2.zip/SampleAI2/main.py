import sampleAI2

if __name__ == '__main__':
    sampleAI2.run()
