import sampleAI

if __name__ == '__main__':
    sampleAI.run()
